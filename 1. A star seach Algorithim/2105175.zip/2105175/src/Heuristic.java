public interface Heuristic{
    int calculateCost(PuzzleConfig puzzleConfig);
}