import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.Stack;

// Main class for the Chain Reaction Game UI and Game Logic
public class ChainReaction {

    private static final int BOARD_ROWS = 9;
    private static final int BOARD_COLS = 6;
    private static final int CELL_SIZE = 50;
    private static final int[][] board = new int[BOARD_ROWS][BOARD_COLS]; // Store orb counts (positive for Red, negative for Blue)
    
    private JFrame frame;
    private JButton[][] buttons;
    private boolean redTurn = true; // Red starts first
    private String gameMode; // 1: Human vs AI, 2: AI vs AI
    private Stack<GameState> historyStack = new Stack<>(); // Stack to hold game states for undo functionality

    // Constructor to initialize the Game UI
    public ChainReaction(String gameMode) {
        this.gameMode = gameMode;
        frame = new JFrame("Chain Reaction");
        frame.setLayout(new GridLayout(BOARD_ROWS, BOARD_COLS));
        buttons = new JButton[BOARD_ROWS][BOARD_COLS];

        // Initialize the board with buttons
        for (int i = 0; i < BOARD_ROWS; i++) {
            for (int j = 0; j < BOARD_COLS; j++) {
                buttons[i][j] = new JButton();
                buttons[i][j].setPreferredSize(new Dimension(CELL_SIZE, CELL_SIZE));
                buttons[i][j].setBackground(Color.WHITE);
                buttons[i][j].addActionListener(new CellClickListener(i, j));
                frame.add(buttons[i][j]);
            }
        }

        // Push initial game state onto the stack (before any moves)
        historyStack.push(new GameState(board, redTurn));

        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    // Action listener for user click on the board (Human vs AI)
    private class CellClickListener implements ActionListener {
        private int row;
        private int col;

        public CellClickListener(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (gameMode.equals("1") && board[row][col] == 0 && redTurn) { // Human's turn (Red)
                board[row][col] = 1; // Red's move
                buttons[row][col].setBackground(Color.RED);
                processMove();
                redTurn = false; // Switch to AI's turn (Blue)
                printBoard();
            }
        }
    }

    // Main method to run the UI
    public static void main(String[] args) {
        String gameMode = JOptionPane.showInputDialog("Enter game mode: \n1. Human Vs AI \n2. AI vs AI");

        if (gameMode == null || (!gameMode.equals("1") && !gameMode.equals("2"))) {
            System.out.println("Invalid Selection. Exiting game ....");
            return;
        }

        ChainReaction game = new ChainReaction(gameMode);
        if (gameMode.equals("1")) {
            game.HumanVsAI();
        } else {
            game.AIvsAI();
        }
    }

    // Handle Human vs AI mode
    public void HumanVsAI() {
        System.out.println("Game Mode: Human vs AI");
        while (!isGameOver(board)) {
            // Human's turn (Red)
            if (redTurn) {
                System.out.println("Human's turn (Red). Waiting for move...");
                continue;
            }

            // AI's turn (Blue)
            else {
                System.out.println("AI's turn (Blue). Making a move...");
                MinimaxAI blueAI = new MinimaxAI();
                int[] move = blueAI.getBestMove(board);  // AI makes its move
                board[move[0]][move[1]] = -1;  // Blue's move
                buttons[move[0]][move[1]].setBackground(Color.BLUE);  // Update UI
                processMove();  // Process the move (check explosions, etc.)
                printBoard();  // Display board after move
                redTurn = true;  // Switch turns to Human
            }
        }
        endGame();
    }

    // Handle AI vs AI mode
    public void AIvsAI() {
        System.out.println("Game Mode: AI vs AI");
        MinimaxAI redAI = new MinimaxAI();
        MinimaxAI blueAI = new MinimaxAI();

        while (!isGameOver(board)) {
            // Red's turn (AI)
            if (redTurn) {
                System.out.println("Red AI's turn. Making a move...");
                int[] move = redAI.getBestMove(board); // Get the best move for Red
                board[move[0]][move[1]] = 1;  // Red's move
                buttons[move[0]][move[1]].setBackground(Color.RED);  // Update UI
                processMove();  // Process the move
                printBoard();  // Display board after move
            }
            // Blue's turn (AI)
            else {
                System.out.println("Blue AI's turn. Making a move...");
                int[] move = blueAI.getBestMove(board); // Get the best move for Blue
                board[move[0]][move[1]] = -1;  // Blue's move
                buttons[move[0]][move[1]].setBackground(Color.BLUE);  // Update UI
                processMove();  // Process the move
                printBoard();  // Display board after move
            }
            redTurn = !redTurn;  // Switch turns
        }
        endGame();
    }

    // End game method (Display results and finalize)
    private void endGame() {
        System.out.println("Game Over");
        if (isRedWinner(board)) {
            System.out.println("Red wins!");
        } else {
            System.out.println("Blue wins!");
        }
    }

    // Check if Red player wins (all blue cells are cleared)
    private boolean isRedWinner(int[][] board) {
        for (int i = 0; i < BOARD_ROWS; i++) {
            for (int j = 0; j < BOARD_COLS; j++) {
                if (board[i][j] == -1) {
                    return false; // If any blue cell is still present, red has not won
                }
            }
        }
        return true; // No blue cells left, red wins
    }

    // Process the current move (Human or AI) and write to the file
    private void processMove() {
        if (redTurn) {
            GameFileCommunication.writeGameState(board, "Human Move:");
        } else {
            GameFileCommunication.writeGameState(board, "AI Move:");
        }

        // Process explosions after every move
        ExplosionLogic.processExplosions(board);
    }

    // Check if the game is over (all cells are filled or one player wins)
    private boolean isGameOver(int[][] board) {
        for (int i = 0; i < BOARD_ROWS; i++) {
            for (int j = 0; j < BOARD_COLS; j++) {
                if (board[i][j] == 0) { // Check for empty spaces
                    return false;
                }
            }
        }
        return true;
    }

    // Print the board in the terminal (update after each move)
    private void printBoard() {
        System.out.println("\nCurrent Board State:");
        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 6; j++) {
                if (board[i][j] == 0) {
                    System.out.print("0 ");
                } else {
                    System.out.print((board[i][j] == 1 ? "R" : "B") + " ");
                }
            }
            System.out.println();
        }
    }
}

// Game File Communication (Reading and Writing the Game State to/from File)
class GameFileCommunication {

    // Reads the game state from a file and returns the current board
    public static int[][] readGameState() {
        int[][] board = new int[9][6];
        try {
            BufferedReader reader = new BufferedReader(new FileReader("gamestate.txt"));
            String line = reader.readLine(); // Read the header (Human Move: or AI Move:)

            // Read the board state
            for (int i = 0; i < 9; i++) {
                line = reader.readLine();
                String[] tokens = line.split(" ");
                for (int j = 0; j < 6; j++) {
                    if (tokens[j].equals("0")) {
                        board[i][j] = 0;
                    } else {
                        int orbCount = Integer.parseInt(tokens[j].substring(0, tokens[j].length() - 1));
                        char color = tokens[j].charAt(tokens[j].length() - 1);
                        board[i][j] = (color == 'R') ? orbCount : -orbCount; // Store color as negative for Blue
                    }
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return board;
    }

    // Writes the updated game state to the file
    public static void writeGameState(int[][] board, String moveType) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("gamestate.txt"));
            writer.write(moveType + "\n");

            // Write the board state
            for (int i = 0; i < 9; i++) {
                for (int j = 0; j < 6; j++) {
                    if (board[i][j] == 0) {
                        writer.write("0 ");
                    } else {
                        int orbCount = Math.abs(board[i][j]);
                        char color = (board[i][j] > 0) ? 'R' : 'B';
                        writer.write(orbCount + "" + color + " ");
                    }
                }
                writer.newLine();
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

// AI Component (MinimaxAI or HeuristicAI)
class MinimaxAI {
    public int[] getBestMove(int[][] board) {
        // This method will generate a move based on the AI's strategy (e.g., Minimax)
        // Returning a dummy move for simplicity
        return new int[]{0, 0};
    }
}

// Explosion Logic
class ExplosionLogic {
    public static void processExplosions(int[][] board) {
        // Implement the explosion logic (e.g., check critical mass, explode and redistribute orbs)
    }
}

